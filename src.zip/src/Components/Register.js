import React from "react";
import { useState } from "react";

const Register = (props) => {
  const [email, setemail] = useState("");
  const [pass, setpass] = useState("");
  const [name, setname] = useState("");

  const handleSubmit = (e) => {
    e.preventdefault();
    console.log(email);
  };

  return (
    
    <>
    <div id="box1"></div>

<div id="box2"></div>
<div id="box3">
      <form onSubmit={handleSubmit}>
        <label htmlFor="name" className="button1">
          Full name
        </label>
        <input
          
          className="button1"
          onchange={(e) => setemail(e.target.value)}
          type="email"
          id="name"
          placeholder="Name"
        ></input>

        <label for="email" className="button1">
          Email
        </label>
        <input
          
          className="button1"
          onchange={(e) => setemail(e.target.value)}
          type="email"
          id="email"
          placeholder="youremail.com"
        ></input>

        <label for="pass" className="button1">
          Password
        </label>
        <input
          
          className="button1"
          onchange={(e) => setpass(e.target.value)}
          type="password"
          id="pass"
          placeholder="********"
        ></input>

        <button className="button1" type="submit">
          Register
        </button>
      </form>
      <button
        className="button2"
        type="submit"
        onClick={() => props.onformswitch("profile")}
      >
        Already have an account?Login here
      </button>

      </div>
    </>
  );
};

export default Register;
