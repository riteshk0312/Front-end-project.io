import React from "react";
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { NavLink } from "react-router-dom";
import { useCart } from "react-use-cart";


const Productcard = ({id,image,title,item}) => {

  const {additem}=useCart();

  return (
    <>
      <Card style={{ width: "18rem" }}>
        <Card.Img variant="top" src={image} />
        <Card.Body>
          <Card.Title> {title}</Card.Title>
          <Card.Text>
            Some quick example text to build on the card title and make up the
            bulk of the card's content.
          </Card.Text>
          <NavLink to =  {`/productinfo/${id}` } ><Button variant="primary">Know more</Button></NavLink><br/><br/>
          <Button variant="primary" onClick={()=>additem(item)}>Add to Cart</Button>
        </Card.Body>
      </Card>
    </>
  );
};

export default Productcard;
