import React from "react";
import { useState } from "react";

const Profile = (props) => {
  const [email, setemail] = useState("");
  const [pass, setpass] = useState("");

  const handleSubmit = (e) => {
    e.preventdefault();
    // console.log(email);
  };

  return (
    <>
      <div id="box1"></div>

      <div id="box2"></div>

      <div id="box3">
        <form onSubmit={handleSubmit}>
          <label htmlFor="email" className="button1">
            Email
          </label>
          <input
            
            className="button1"
            onchange={(e) => setemail(e.target.value)}
            type="email"
            id="email"
            placeholder="youremail.com"
          ></input>

          <label htmlFor="pass" className="button1">
            Password
          </label>
          <input
            
            className="button1"
            onchange={(e) => setpass(e.target.value)}
            type="password"
            id="pass"
            placeholder="********"
          ></input>

          <button className="button1" type="submit">
            Login
          </button>
        </form>
        <button
          className="button2"
          type="submit"
          onClick={() => props.onformswitch("register")}
        >
          Don't have an account ? Register here
        </button>
      </div>
    </>
  );
};

export default Profile;
